from flask import Flask, render_template, redirect, url_for, request
import shutil
import os

app = Flask(__name__)


c_list = []
@app.route('/login',methods = ['POST', 'GET'])
def login():
    if request.method == 'POST':
      user = request.form['nm']
      print("Worked")
      os.chdir("C:/Users/Weston Simon/Desktop/New folder (2)")
      try:
        userdir = os.mkdir(user)
      except FileExistsError:
         os.chdir("C:/Users/Weston Simon/Desktop/New folder (2)/" + user)
         print("This user already has an account folder")
      try:
          classes_names = open('classes.txt', 'x')
          classes_names.close()
          
      except FileExistsError:
        print("user already has a class file")
      return redirect(url_for('name', name = user))

    else:
      user = request.args.get('nm')
      print("meh")
      return render_template('index.html')

@app.route('/name/<name>')
def name(name):
     while(True):
         classes_names = open('classes.txt', 'r')
         classes = classes_names.readline()
         classes = classes.strip("\n")
         c_list.append(classes)

         if classes != "":
             continue
         elif classes == "":
              break
     print(c_list)
     for class_ in c_list:
        class_name_format = "<li>" + class_ + "</li>"
        class_name = class_name_format + class_name + "<br>"
     return render_template('name.html',name=name, class_name=class_name)

if __name__ == '__main__':
    app.run(debug=True)